<?php

// Database connection details
$conn = mysqli_connect('localhost', 'root', '', 'online_book_store') or die('Connection failed');

// Check connection (Optional: for debugging)
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

?>