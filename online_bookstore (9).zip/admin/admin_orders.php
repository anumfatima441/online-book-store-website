<?php
include __DIR__ . '/../config.php';
session_start();
if(!isset($_SESSION['admin_id'])){
   header('location:login.php');
   exit();
}

$user_id = $_SESSION['admin_id'];
$check_admin = mysqli_query($conn, "SELECT role FROM users WHERE id = '$user_id'") or die('query failed');
$user_data = mysqli_fetch_assoc($check_admin);
if(!$user_data){
    header('location:login.php');
    exit();
}

// Uncomment if role-based admin access is enforced
// if($user_data['role'] != 'admin'){
//    header('location:home.php');
//    exit();
// }

$message = '';
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_id'], $_POST['order_action'])){
    $order_id = mysqli_real_escape_string($conn, $_POST['order_id']);
    $order_action = $_POST['order_action'];
    $new_status = '';

    if($order_action === 'confirm'){
        $new_status = 'processing';
    } elseif($order_action === 'deliver'){
        $new_status = 'completed';
    } elseif($order_action === 'cancel'){
        $new_status = 'cancelled';
    }

    if($new_status){
        $update_query = mysqli_query($conn, "UPDATE orders SET status = '$new_status', updated_at = NOW() WHERE id = '$order_id'");
        if($update_query){
            $message = 'Order #' . $order_id . ' updated to ' . ucfirst($new_status) . '.';
        } else {
            $message = 'Unable to update order. Please try again.';
        }
        header('Location: admin_orders.php?msg=' . urlencode($message));
        exit();
    }
}

$status_filter = '';
$allowed_statuses = ['pending', 'processing', 'completed', 'cancelled'];
if(isset($_GET['status']) && in_array($_GET['status'], $allowed_statuses, true)){
    $status_filter = $_GET['status'];
}
$where = '';
if($status_filter){
    $status_safe = mysqli_real_escape_string($conn, $status_filter);
    $where = "WHERE o.status = '$status_safe'";
}

$total_orders = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM orders"))['count'] ?? 0;
$pending_orders = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM orders WHERE status = 'pending'"))['count'] ?? 0;
$processing_orders = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM orders WHERE status = 'processing'"))['count'] ?? 0;
$completed_orders = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM orders WHERE status = 'completed'"))['count'] ?? 0;
$cancelled_orders = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM orders WHERE status = 'cancelled'"))['count'] ?? 0;
$total_revenue = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(total_amount) as total FROM orders WHERE status = 'completed'"))['total'] ?? 0;

$orders = mysqli_query($conn, "SELECT o.id, o.user_id, o.total_amount, o.status, o.payment_method, o.created_at, o.updated_at, u.name as user_name, COALESCE(SUM(oi.quantity), 0) as item_count
    FROM orders o
    LEFT JOIN users u ON u.id = o.user_id
    LEFT JOIN order_items oi ON oi.order_id = o.id
    $where
    GROUP BY o.id, o.user_id, o.total_amount, o.status, o.payment_method, o.created_at, o.updated_at, u.name
    ORDER BY o.created_at DESC");

if(isset($_GET['msg'])){
    $message = htmlspecialchars($_GET['msg']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <title>Orders - Book Hub Admin</title>
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
   <link rel="stylesheet" href="admin-style.css">
</head>
<body>
<div class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <div class="admin-profile">
            <div class="admin-avatar"><i class="fas fa-user-shield"></i></div>
            <div class="admin-info">
                <h6><?php echo $_SESSION['admin_name'] ?? 'Admin'; ?></h6>
                <small>Administrator</small>
            </div>
        </div>
        <button class="sidebar-close d-lg-none" id="sidebarClose"><i class="fas fa-times"></i></button>
    </div>
    <nav class="sidebar-nav">
        <ul class="nav flex-column">
            <li class="nav-item"><a class="nav-link" href="admin.php"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_profile.php"><i class="fas fa-user-circle"></i><span>Admin Profile</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_books.php"><i class="fas fa-book"></i><span>Manage Books</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_categories.php"><i class="fas fa-tags"></i><span>Categories</span></a></li>
            <li class="nav-item"><a class="nav-link active" href="admin_orders.php"><i class="fas fa-shopping-cart"></i><span>Orders</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_users.php"><i class="fas fa-users"></i><span>Users</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_payments.php"><i class="fas fa-credit-card"></i><span>Payments</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_reviews.php"><i class="fas fa-star"></i><span>Reviews</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_notifications.php"><i class="fas fa-bell"></i><span>Notifications</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_reports.php"><i class="fas fa-chart-bar"></i><span>Reports</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_settings.php"><i class="fas fa-cog"></i><span>Settings</span></a></li>
            <li class="nav-item mt-3"><a class="nav-link text-danger" href="logout.php"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a></li>
        </ul>
    </nav>
</div>
<div class="main-content" id="mainContent">
    <nav class="navbar navbar-expand-lg navbar-dark admin-navbar">
        <div class="container-fluid">
            <button class="sidebar-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
            <a class="navbar-brand ms-3" href="#"><i class="fas fa-book-open"></i><span>Book Hub Admin</span></a>
            <div class="d-flex align-items-center ms-auto">
                <div class="dropdown">
                    <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" role="button" data-bs-toggle="dropdown">
                        <div class="admin-mini-avatar"><i class="fas fa-user-shield"></i></div>
                        <span class="d-none d-md-block ms-2"><?php echo $_SESSION['admin_name'] ?? 'Admin'; ?></span>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="admin_profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                        <li><a class="dropdown-item" href="admin_settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-danger" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>
    <div class="content-wrapper">
        <div class="container-fluid">
            <div class="page-header">
                <h2 class="page-title">Orders</h2>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="admin.php">Dashboard</a></li>
                        <li class="breadcrumb-item active">Orders</li>
                    </ol>
                </nav>
            </div>
            <div class="row g-4 mb-4">
                <div class="col-lg-2_4 col-md-6" style="flex: 0 0 20%;">
                    <div class="stat-card primary">
                        <div class="stat-card-body">
                            <div class="stat-icon"><i class="fas fa-shopping-bag"></i></div>
                            <div class="stat-info">
                                <h3><?php echo $total_orders; ?></h3>
                                <p>Total Orders</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2_4 col-md-6" style="flex: 0 0 20%;">
                    <div class="stat-card warning">
                        <div class="stat-card-body">
                            <div class="stat-icon"><i class="fas fa-clock"></i></div>
                            <div class="stat-info">
                                <h3><?php echo $pending_orders; ?></h3>
                                <p>Pending Orders</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2_4 col-md-6" style="flex: 0 0 20%;">
                    <div class="stat-card info">
                        <div class="stat-card-body">
                            <div class="stat-icon"><i class="fas fa-spinner"></i></div>
                            <div class="stat-info">
                                <h3><?php echo $processing_orders; ?></h3>
                                <p>Processing</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2_4 col-md-6" style="flex: 0 0 20%;">
                    <div class="stat-card success">
                        <div class="stat-card-body">
                            <div class="stat-icon"><i class="fas fa-check-circle"></i></div>
                            <div class="stat-info">
                                <h3><?php echo $completed_orders; ?></h3>
                                <p>Completed</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-2_4 col-md-6" style="flex: 0 0 20%;">
                    <div class="stat-card danger">
                        <div class="stat-card-body">
                            <div class="stat-icon"><i class="fas fa-ban"></i></div>
                            <div class="stat-info">
                                <h3><?php echo $cancelled_orders; ?></h3>
                                <p>Cancelled Orders</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card table-card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5><i class="fas fa-list me-2"></i>All Orders</h5>
                    <div class="d-flex gap-2 align-items-center">
                        <form method="get" class="d-flex align-items-center">
                            <select name="status" class="form-select form-select-sm me-2" onchange="this.form.submit()">
                                <option value=""<?php echo $status_filter === '' ? ' selected' : ''; ?>>All Status</option>
                                <option value="pending"<?php echo $status_filter === 'pending' ? ' selected' : ''; ?>>Pending</option>
                                <option value="processing"<?php echo $status_filter === 'processing' ? ' selected' : ''; ?>>Processing</option>
                                <option value="completed"<?php echo $status_filter === 'completed' ? ' selected' : ''; ?>>Completed</option>
                                <option value="cancelled"<?php echo $status_filter === 'cancelled' ? ' selected' : ''; ?>>Cancelled</option>
                            </select>
                        </form>
                        <button class="btn btn-sm btn-primary"><i class="fas fa-download me-2"></i>Export</button>
                    </div>
                </div>
                <div class="card-body p-0">
                    <?php if(!empty($message)): ?>
                        <div class="alert alert-success rounded-0 mb-0 p-3">
                            <?php echo $message; ?>
                        </div>
                    <?php endif; ?>
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>Order ID</th>
                                    <th>Customer</th>
                                    <th>Items</th>
                                    <th>Total</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($orders && mysqli_num_rows($orders) > 0): ?>
                                    <?php while($order = mysqli_fetch_assoc($orders)): ?>
                                        <?php
                                            $status = $order['status'];
                                            $badge_class = 'secondary';
                                            if($status === 'pending') $badge_class = 'warning';
                                            elseif($status === 'processing') $badge_class = 'info';
                                            elseif($status === 'completed') $badge_class = 'success';
                                            elseif($status === 'cancelled') $badge_class = 'danger';
                                        ?>
                                        <tr>
                                            <td>#ORD-<?php echo str_pad($order['id'], 4, '0', STR_PAD_LEFT); ?></td>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <div class="admin-mini-avatar me-2"><i class="fas fa-user"></i></div>
                                                    <?php echo htmlspecialchars($order['user_name'] ?: 'Unknown'); ?>
                                                </div>
                                            </td>
                                            <td><?php echo (int)$order['item_count']; ?> item<?php echo $order['item_count'] == 1 ? '' : 's'; ?></td>
                                            <td><strong>Rs. <?php echo number_format((float)$order['total_amount'], 2); ?></strong></td>
                                            <td><span class="badge bg-<?php echo $badge_class; ?>"><?php echo ucfirst($status); ?></span></td>
                                            <td><?php echo date('M d, Y', strtotime($order['created_at'])); ?></td>
                                            <td>
                                                <?php if($status === 'pending'): ?>
                                                    <form method="post" class="d-inline">
                                                        <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                                                        <input type="hidden" name="order_action" value="confirm">
                                                        <button type="submit" name="update_order" class="btn btn-sm btn-outline-info" title="Confirm Order">
                                                            <i class="fas fa-check-circle"></i>
                                                        </button>
                                                    </form>
                                                    <form method="post" class="d-inline ms-1">
                                                        <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                                                        <input type="hidden" name="order_action" value="cancel">
                                                        <button type="submit" name="update_order" class="btn btn-sm btn-outline-danger" title="Cancel Order" onclick="return confirm('Are you sure you want to cancel this order?');">
                                                            <i class="fas fa-times"></i>
                                                        </button>
                                                    </form>
                                                <?php elseif($status === 'processing'): ?>
                                                    <form method="post" class="d-inline">
                                                        <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                                                        <input type="hidden" name="order_action" value="deliver">
                                                        <button type="submit" name="update_order" class="btn btn-sm btn-outline-success" title="Mark as Delivered">
                                                            <i class="fas fa-truck"></i>
                                                        </button>
                                                    </form>
                                                    <form method="post" class="d-inline ms-1">
                                                        <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                                                        <input type="hidden" name="order_action" value="cancel">
                                                        <button type="submit" name="update_order" class="btn btn-sm btn-outline-danger" title="Cancel Order" onclick="return confirm('Are you sure you want to cancel this order?');">
                                                            <i class="fas fa-times"></i>
                                                        </button>
                                                    </form>
                                                <?php else: ?>
                                                    <button class="btn btn-sm btn-outline-secondary" disabled><i class="fas fa-ban"></i></button>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="7" class="text-center py-4">No orders found.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <footer class="admin-footer">
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center">
                <p class="mb-0">&copy; 2026 Book Hub. All rights reserved.</p>
                <p class="mb-0">Admin Panel v1.0</p>
            </div>
        </div>
    </footer>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="admin-script.js"></script>
</body>
</html>
