# Online Book Store - Setup Guide

## Project Overview
A complete online book store web application built with PHP, MySQL, and Bootstrap.

## Features
✅ User Authentication (Login/Register)
✅ Browse Books with Search
✅ View Book Details & Ratings
✅ Shopping Cart with Add/Remove Items
✅ Checkout System
✅ Purchase History
✅ Responsive Design
✅ Admin System Ready

## Installation Steps

### 1. Database Setup
```sql
1. Open phpMyAdmin (http://localhost/phpmyadmin)
2. Import the `db_setup.sql` file
3. This will create the `online_book_store` database with all tables and sample data
```

### 2. File Structure
```
online_bookstore/
├── index.php           (Homepage - Browse Books)
├── login.php           (User Login)
├── register.php        (User Registration)
├── home.php            (Logged-in Home)
├── add_to_cart.php     (Add Book to Cart)
├── cart.php            (View Shopping Cart)
├── checkout.php        (Complete Purchase)
├── purchases.php       (View Purchase History)
├── admin.php           (Admin Dashboard)
├── admin_orders.php    (Admin Order Management)
├── logout.php          (Logout)
├── config.php          (Database Configuration)
├── db_setup.sql        (Database Schema)
├── style.css           (Styling)
└── README.md           (This file)
```

### 3. Configuration
- Open `config.php` and verify database connection settings:
  - Host: `localhost`
  - User: `root`
  - Database: `online_book_store`

### 4. Access the Application

#### For Visitors:
1. Go to `http://localhost/online_bookstore/`
2. Browse books without login
3. Click "Login" to create an account or login

#### For Users (Sample):
1. Click "Register" to create a new account
2. Or use sample account (if created manually in DB):
   - Email: `user@example.com`
   - Password: `password123`

#### For Admin (Sample):
1. Email: `admin@example.com`
2. Password: `admin123`
3. Visit `admin.php` or `admin_orders.php` after login to manage orders.

## User Workflow

### 1. Registration
- Visit `register.php`
- Enter Name, Email, Password, Confirm Password
- Account is created and ready to login

### 2. Browse Books (Homepage)
- View all books with:
  - Cover images
  - Title & Author
  - Price
  - Rating (1-5 stars)
  - Description
  - Add to Cart button

### 3. Search Books
- Use search box on index.php
- Search by: Title, Author, or Description

### 4. Shopping Cart
- Add books from homepage
- View cart at `cart.php`
- See details: Book Cover, Price, Quantity, Subtotal
- Remove books if needed
- View Total Price

### 5. Checkout
- Click "Checkout" button in cart
- Items are transferred to "Purchases" table
- Cart is cleared
- See confirmation message

### 6. View Purchases
- Access via "Purchases" link in navbar
- See all purchased books with:
  - Book details
  - Quantity
  - Purchase Date & Time

## Database Tables

### users
- id, name, email, password, user_type (user/admin)

### books
- id, title, author, price, image, description, rating

### cart
- id, user_id, book_id, quantity

### purchases
- id, user_id, book_id, quantity, purchased_at

## Sample Books Included
1. The Great Gatsby - Rs. 500
2. To Kill a Mockingbird - Rs. 600
3. Introduction to Algorithms - Rs. 1200
4. Clean Code - Rs. 800
5. The Pragmatic Programmer - Rs. 900
6. Computer Networks - Rs. 1100
7. Operating System Concepts - Rs. 1000
8. Database System Concepts - Rs. 950
9. Artificial Intelligence: A Modern Approach - Rs. 1300
10. Python Crash Course - Rs. 700
11. Head First Design Patterns - Rs. 850
12. Code Complete - Rs. 950
13. A Brief History of Time - Rs. 850
14. The Selfish Gene - Rs. 780

## Security Features
- Session-based authentication
- Password MD5 encryption (consider bcrypt for production)
- SQL injection prevention with mysqli_real_escape_string()
- User input validation

## Styling
- Bootstrap 5.3.0 for responsive design
- Custom CSS with:
  - Modern color scheme (#001f3f navy, #ffc107 yellow)
  - Smooth transitions and hover effects
  - Responsive grid layout
  - Professional card design

## Browser Compatibility
- Chrome/Edge (Latest)
- Firefox (Latest)
- Safari (Latest)
- Mobile Responsive

## Future Enhancements
- Admin Dashboard
- Book Categories/Filters
- User Reviews & Ratings
- Wishlist Feature
- Payment Gateway Integration
- Email Notifications
- Advanced Search Filters
- Order Tracking
- Digital Book Downloads

## Troubleshooting

### Issue: "Connection failed"
- Check if MySQL is running in XAMPP
- Verify database name in config.php

### Issue: Images not loading
- Check internet connection (uses OpenLibrary API)
- Images have fallback placeholders

### Issue: Cart not working
- Ensure user is logged in
- Check browser cookies/session

### Issue: Purchase history empty
- Make sure to complete checkout
- Cart items are deleted after checkout

## Support
For issues or improvements, check the following:
1. Database connection
2. PHP session is enabled
3. File permissions
4. XAMPP services running

---
**Status:** ✅ Core Features Complete
**Last Updated:** April 7, 2026
