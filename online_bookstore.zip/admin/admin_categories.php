<?php
include __DIR__ . '/../config.php';
session_start();
if(!isset($_SESSION['admin_id'])){ header('location:login.php'); exit(); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <title>Categories - Book Hub Admin</title>
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
   <link rel="stylesheet" href="admin-style.css">
</head>
<body>
<div class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <div class="admin-profile">
            <div class="admin-avatar"><i class="fas fa-user-shield"></i></div>
            <div class="admin-info">
                <h6><?php echo $_SESSION['admin_name'] ?? 'Admin'; ?></h6>
                <small>Administrator</small>
            </div>
        </div>
        <button class="sidebar-close d-lg-none" id="sidebarClose"><i class="fas fa-times"></i></button>
    </div>
    <nav class="sidebar-nav">
        <ul class="nav flex-column">
            <li class="nav-item"><a class="nav-link" href="admin.php"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_profile.php"><i class="fas fa-user-circle"></i><span>Admin Profile</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_books.php"><i class="fas fa-book"></i><span>Manage Books</span></a></li>
            <li class="nav-item"><a class="nav-link active" href="admin_categories.php"><i class="fas fa-tags"></i><span>Categories</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_orders.php"><i class="fas fa-shopping-cart"></i><span>Orders</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_users.php"><i class="fas fa-users"></i><span>Users</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_payments.php"><i class="fas fa-credit-card"></i><span>Payments</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_reviews.php"><i class="fas fa-star"></i><span>Reviews</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_notifications.php"><i class="fas fa-bell"></i><span>Notifications</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_reports.php"><i class="fas fa-chart-bar"></i><span>Reports</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_settings.php"><i class="fas fa-cog"></i><span>Settings</span></a></li>
            <li class="nav-item mt-3"><a class="nav-link text-danger" href="logout.php"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a></li>
        </ul>
    </nav>
</div>
<div class="main-content" id="mainContent">
    <nav class="navbar navbar-expand-lg navbar-dark admin-navbar">
        <div class="container-fluid">
            <button class="sidebar-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
            <a class="navbar-brand ms-3" href="#"><i class="fas fa-book-open"></i><span>Book Hub Admin</span></a>
            <div class="d-flex align-items-center ms-auto">
                <div class="dropdown">
                    <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" role="button" data-bs-toggle="dropdown">
                        <div class="admin-mini-avatar"><i class="fas fa-user-shield"></i></div>
                        <span class="d-none d-md-block ms-2"><?php echo $_SESSION['admin_name'] ?? 'Admin'; ?></span>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="admin_profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                        <li><a class="dropdown-item" href="admin_settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-danger" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>
    <div class="content-wrapper">
        <div class="container-fluid">
            <div class="page-header">
                <h2 class="page-title">Categories</h2>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="admin.php">Dashboard</a></li>
                        <li class="breadcrumb-item active">Categories</li>
                    </ol>
                </nav>
            </div>
            <div class="row g-4">
                <div class="col-lg-4">
                    <div class="card">
                        <div class="card-header"><h5><i class="fas fa-plus me-2"></i>Add Category</h5></div>
                        <div class="card-body">
                            <form>
                                <div class="mb-3"><label class="form-label">Category Name</label><input type="text" class="form-control" placeholder="Enter category name"></div>
                                <div class="mb-3"><label class="form-label">Description</label><textarea class="form-control" rows="3"></textarea></div>
                                <button class="btn btn-primary w-100"><i class="fas fa-save me-2"></i>Save Category</button>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="card table-card">
                        <div class="card-header"><h5><i class="fas fa-tags me-2"></i>All Categories</h5></div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover mb-0">
                                    <thead><tr><th>ID</th><th>Name</th><th>Books</th><th>Actions</th></tr></thead>
                                    <tbody>
                                        <tr><td>#1</td><td>Fiction</td><td><span class="badge bg-primary">45</span></td><td><button class="btn btn-sm btn-outline-primary"><i class="fas fa-edit"></i></button> <button class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button></td></tr>
                                        <tr><td>#2</td><td>Technology</td><td><span class="badge bg-primary">32</span></td><td><button class="btn btn-sm btn-outline-primary"><i class="fas fa-edit"></i></button> <button class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button></td></tr>
                                        <tr><td>#3</td><td>Science</td><td><span class="badge bg-primary">28</span></td><td><button class="btn btn-sm btn-outline-primary"><i class="fas fa-edit"></i></button> <button class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button></td></tr>
                                        <tr><td>#4</td><td>History</td><td><span class="badge bg-primary">15</span></td><td><button class="btn btn-sm btn-outline-primary"><i class="fas fa-edit"></i></button> <button class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button></td></tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <footer class="admin-footer">
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center">
                <p class="mb-0">&copy; 2026 Book Hub. All rights reserved.</p>
                <p class="mb-0">Admin Panel v1.0</p>
            </div>
        </div>
    </footer>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="admin-script.js"></script>
</body>
</html>
