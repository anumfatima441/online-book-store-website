<?php
include __DIR__ . '/../config.php';
session_start();

// Check if user is logged in and is admin
if(!isset($_SESSION['admin_id'])){
   header('location:login.php');
   exit();
}

// Check admin role (assuming role is stored in session or you can modify as needed)
$user_id = $_SESSION['admin_id'];
$check_admin = mysqli_query($conn, "SELECT role FROM users WHERE id = '$user_id'") or die('query failed');
$user_data = mysqli_fetch_assoc($check_admin);

// For now, allow access (you can uncomment this when you have admin roles)
// if($user_data['role'] != 'admin'){
//    header('location:home.php');
//    exit();
// }

// Get dashboard statistics with error handling
$total_books = 0;
$total_users = 0;
$total_orders = 0;
$total_revenue = 0;
$recent_orders = false;
$low_stock = false;

// Check if tables exist and get data
$result = mysqli_query($conn, "SHOW TABLES LIKE 'books'");
if(mysqli_num_rows($result) > 0) {
    $total_books = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM books"))['count'] ?? 0;
    // Get low stock books (if stock column exists)
    $low_stock = @mysqli_query($conn, "SELECT * FROM books WHERE stock < 10 LIMIT 5");
}

$result = mysqli_query($conn, "SHOW TABLES LIKE 'users'");
if(mysqli_num_rows($result) > 0) {
    $total_users = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM users"))['count'] ?? 0;
}

$result = mysqli_query($conn, "SHOW TABLES LIKE 'orders'");
if(mysqli_num_rows($result) > 0) {
    $total_orders = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM orders"))['count'] ?? 0;
    $revenue_query = mysqli_query($conn, "SELECT SUM(total_amount) as total FROM orders WHERE status = 'completed'");
    if($revenue_query) {
        $total_revenue = mysqli_fetch_assoc($revenue_query)['total'] ?? 0;
    }
    $recent_orders = @mysqli_query($conn, "SELECT o.*, u.name as user_name FROM orders o JOIN users u ON o.user_id = u.id ORDER BY o.created_at DESC LIMIT 5");
}

$admin_notifications = mysqli_query($conn, "SELECT * FROM notifications WHERE recipient_type = 'admin' ORDER BY created_at DESC LIMIT 5");
$admin_unread_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as cnt FROM notifications WHERE recipient_type = 'admin' AND is_read = 0"))['cnt'] ?? 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Admin Dashboard - Book Hub</title>
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
   <link rel="stylesheet" href="admin-style.css">
</head>
<body>

<!-- Sidebar -->
<div class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <div class="admin-profile">
            <div class="admin-avatar">
                <i class="fas fa-user-shield"></i>
            </div>
            <div class="admin-info">
                <h6><?php echo $_SESSION['admin_name'] ?? 'Admin'; ?></h6>
                <small>Administrator</small>
            </div>
        </div>
        <button class="sidebar-close d-lg-none" id="sidebarClose">
            <i class="fas fa-times"></i>
        </button>
    </div>
    
    <nav class="sidebar-nav">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link active" href="admin.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="admin_profile.php">
                    <i class="fas fa-user-circle"></i>
                    <span>Admin Profile</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="admin_books.php">
                    <i class="fas fa-book"></i>
                    <span>Manage Books</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="admin_categories.php">
                    <i class="fas fa-tags"></i>
                    <span>Categories</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="admin_orders.php">
                    <i class="fas fa-shopping-cart"></i>
                    <span>Orders</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="admin_users.php">
                    <i class="fas fa-users"></i>
                    <span>Users</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="admin_payments.php">
                    <i class="fas fa-credit-card"></i>
                    <span>Payments</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="admin_reviews.php">
                    <i class="fas fa-star"></i>
                    <span>Reviews</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="admin_notifications.php">
                    <i class="fas fa-bell"></i>
                    <span>Notifications</span>
                    <span class="badge bg-danger ms-auto">3</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="admin_reports.php">
                    <i class="fas fa-chart-bar"></i>
                    <span>Reports</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="admin_settings.php">
                    <i class="fas fa-cog"></i>
                    <span>Settings</span>
                </a>
            </li>
            <li class="nav-item mt-3">
                <a class="nav-link text-danger" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </nav>
</div>

<!-- Main Content -->
<div class="main-content" id="mainContent">
    <!-- Top Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark admin-navbar">
        <div class="container-fluid">
            <button class="sidebar-toggle" id="sidebarToggle">
                <i class="fas fa-bars"></i>
            </button>
            
            <a class="navbar-brand ms-3" href="#">
                <i class="fas fa-book-open"></i>
                <span>Book Hub Admin</span>
            </a>
            
            <div class="d-flex align-items-center ms-auto">
                <!-- Search -->
                <div class="search-box d-none d-md-block me-3">
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                        <input type="text" class="form-control" placeholder="Search...">
                    </div>
                </div>
                
                <!-- Notifications -->
                <div class="dropdown me-3">
                    <a class="nav-link position-relative" href="#" role="button" data-bs-toggle="dropdown">
                        <i class="fas fa-bell"></i>
                        <?php if($admin_unread_count > 0): ?>
                        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                            <?php echo $admin_unread_count; ?>
                        </span>
                        <?php endif; ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end notification-dropdown">
                        <li><h6 class="dropdown-header">Notifications</h6></li>
                        <?php if($admin_notifications && mysqli_num_rows($admin_notifications) > 0): ?>
                            <?php while($notification = mysqli_fetch_assoc($admin_notifications)): ?>
                                <li><a class="dropdown-item" href="admin_notifications.php"><i class="fas fa-bell text-primary"></i> <?php echo htmlspecialchars($notification['title']); ?></a></li>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <li><span class="dropdown-item text-muted">No notifications</span></li>
                        <?php endif; ?>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-center" href="admin_notifications.php">View all</a></li>
                    </ul>
                </div>
                
                <!-- Admin Profile -->
                <div class="dropdown">
                    <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" role="button" data-bs-toggle="dropdown">
                        <div class="admin-mini-avatar">
                            <i class="fas fa-user-shield"></i>
                        </div>
                        <span class="d-none d-md-block ms-2"><?php echo $_SESSION['admin_name'] ?? 'Admin'; ?></span>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="admin_profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                        <li><a class="dropdown-item" href="admin_settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-danger" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>

    <!-- Dashboard Content -->
    <div class="content-wrapper">
        <div class="container-fluid">
            <!-- Page Header -->
            <div class="page-header">
                <div class="row align-items-center">
                    <div class="col">
                        <h2 class="page-title">Dashboard Overview</h2>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item active">Dashboard</li>
                            </ol>
                        </nav>
                    </div>
                    <div class="col-auto">
                        <span class="text-muted"><?php echo date('l, F j, Y'); ?></span>
                    </div>
                </div>
            </div>

            <!-- Stats Cards -->
            <div class="row g-4 mb-4">
                <div class="col-xl-3 col-md-6">
                    <div class="stat-card primary">
                        <div class="stat-card-body">
                            <div class="stat-icon">
                                <i class="fas fa-book"></i>
                            </div>
                            <div class="stat-info">
                                <h3><?php echo $total_books; ?></h3>
                                <p>Total Books</p>
                            </div>
                        </div>
                        <div class="stat-footer">
                            <a href="admin_books.php">View all <i class="fas fa-arrow-right"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="stat-card success">
                        <div class="stat-card-body">
                            <div class="stat-icon">
                                <i class="fas fa-users"></i>
                            </div>
                            <div class="stat-info">
                                <h3><?php echo $total_users; ?></h3>
                                <p>Total Users</p>
                            </div>
                        </div>
                        <div class="stat-footer">
                            <a href="admin_users.php">View all <i class="fas fa-arrow-right"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="stat-card warning">
                        <div class="stat-card-body">
                            <div class="stat-icon">
                                <i class="fas fa-shopping-cart"></i>
                            </div>
                            <div class="stat-info">
                                <h3><?php echo $total_orders; ?></h3>
                                <p>Total Orders</p>
                            </div>
                        </div>
                        <div class="stat-footer">
                            <a href="admin_orders.php">View all <i class="fas fa-arrow-right"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="stat-card info">
                        <div class="stat-card-body">
                            <div class="stat-icon">
                                <i class="fas fa-dollar-sign"></i>
                            </div>
                            <div class="stat-info">
                                <h3>Rs. <?php echo number_format($total_revenue); ?></h3>
                                <p>Total Revenue</p>
                            </div>
                        </div>
                        <div class="stat-footer">
                            <a href="admin_reports.php">View report <i class="fas fa-arrow-right"></i></a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Charts & Tables Row -->
            <div class="row g-4 mb-4">
                <!-- Sales Chart -->
                <div class="col-lg-8">
                    <div class="card chart-card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5><i class="fas fa-chart-line me-2"></i>Sales Overview</h5>
                            <div class="btn-group btn-group-sm">
                                <button class="btn btn-outline-primary active">Weekly</button>
                                <button class="btn btn-outline-primary">Monthly</button>
                                <button class="btn btn-outline-primary">Yearly</button>
                            </div>
                        </div>
                        <div class="card-body">
                            <canvas id="salesChart" height="300"></canvas>
                        </div>
                    </div>
                </div>
                
                <!-- Top Categories -->
                <div class="col-lg-4">
                    <div class="card chart-card">
                        <div class="card-header">
                            <h5><i class="fas fa-chart-pie me-2"></i>Top Categories</h5>
                        </div>
                        <div class="card-body">
                            <canvas id="categoryChart" height="300"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Tables Row -->
            <div class="row g-4">
                <!-- Recent Orders -->
                <div class="col-lg-8">
                    <div class="card table-card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5><i class="fas fa-shopping-bag me-2"></i>Recent Orders</h5>
                            <a href="admin_orders.php" class="btn btn-sm btn-primary">View All</a>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover mb-0">
                                    <thead>
                                        <tr>
                                            <th>Order ID</th>
                                            <th>Customer</th>
                                            <th>Amount</th>
                                            <th>Status</th>
                                            <th>Date</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if($recent_orders && mysqli_num_rows($recent_orders) > 0): 
                                            while($order = mysqli_fetch_assoc($recent_orders)): ?>
                                        <tr>
                                            <td>#<?php echo $order['id'] ?? '0001'; ?></td>
                                            <td><?php echo $order['user_name'] ?? 'Guest'; ?></td>
                                            <td>Rs. <?php echo number_format($order['total_amount'] ?? 0); ?></td>
                                            <td>
                                                <span class="badge bg-<?php echo ($order['status'] ?? 'pending') == 'completed' ? 'success' : (($order['status'] ?? 'pending') == 'pending' ? 'warning' : 'info'); ?>">
                                                    <?php echo ucfirst($order['status'] ?? 'Pending'); ?>
                                                </span>
                                            </td>
                                            <td><?php echo date('M d, Y', strtotime($order['created_at'] ?? 'now')); ?></td>
                                            <td>
                                                <a href="admin_orders.php?id=<?php echo $order['id']; ?>" class="btn btn-sm btn-outline-primary">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                            </td>
                                        </tr>
                                        <?php endwhile; else: ?>
                                        <tr>
                                            <td colspan="6" class="text-center py-4">No recent orders</td>
                                        </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Low Stock Alert -->
                <div class="col-lg-4">
                    <div class="card table-card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5><i class="fas fa-exclamation-triangle me-2"></i>Low Stock Alert</h5>
                            <a href="admin_books.php" class="btn btn-sm btn-primary">Manage</a>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover mb-0">
                                    <thead>
                                        <tr>
                                            <th>Book</th>
                                            <th>Stock</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if($low_stock && mysqli_num_rows($low_stock) > 0): 
                                            while($book = mysqli_fetch_assoc($low_stock)): ?>
                                        <tr>
                                            <td><?php echo $book['title']; ?></td>
                                            <td>
                                                <span class="badge bg-<?php echo $book['stock'] < 5 ? 'danger' : 'warning'; ?>">
                                                    <?php echo $book['stock']; ?> left
                                                </span>
                                            </td>
                                            <td>
                                                <a href="admin_books.php?edit=<?php echo $book['id']; ?>" class="btn btn-sm btn-outline-primary">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                            </td>
                                        </tr>
                                        <?php endwhile; else: ?>
                                        <tr>
                                            <td colspan="3" class="text-center py-4">No low stock items</td>
                                        </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="row g-4 mt-2">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h5><i class="fas fa-bolt me-2"></i>Quick Actions</h5>
                        </div>
                        <div class="card-body">
                            <div class="row g-3">
                                <div class="col-lg-2 col-md-4 col-6">
                                    <a href="admin_books.php?action=add" class="quick-action-btn">
                                        <div class="icon bg-primary">
                                            <i class="fas fa-plus"></i>
                                        </div>
                                        <span>Add Book</span>
                                    </a>
                                </div>
                                <div class="col-lg-2 col-md-4 col-6">
                                    <a href="admin_categories.php?action=add" class="quick-action-btn">
                                        <div class="icon bg-success">
                                            <i class="fas fa-tag"></i>
                                        </div>
                                        <span>Add Category</span>
                                    </a>
                                </div>
                                <div class="col-lg-2 col-md-4 col-6">
                                    <a href="admin_orders.php" class="quick-action-btn">
                                        <div class="icon bg-warning">
                                            <i class="fas fa-clipboard-list"></i>
                                        </div>
                                        <span>View Orders</span>
                                    </a>
                                </div>
                                <div class="col-lg-2 col-md-4 col-6">
                                    <a href="admin_users.php" class="quick-action-btn">
                                        <div class="icon bg-info">
                                            <i class="fas fa-user-plus"></i>
                                        </div>
                                        <span>Manage Users</span>
                                    </a>
                                </div>
                                <div class="col-lg-2 col-md-4 col-6">
                                    <a href="admin_reports.php" class="quick-action-btn">
                                        <div class="icon bg-secondary">
                                            <i class="fas fa-file-alt"></i>
                                        </div>
                                        <span>Generate Report</span>
                                    </a>
                                </div>
                                <div class="col-lg-2 col-md-4 col-6">
                                    <a href="admin_settings.php" class="quick-action-btn">
                                        <div class="icon bg-dark">
                                            <i class="fas fa-cogs"></i>
                                        </div>
                                        <span>Settings</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Footer -->
    <footer class="admin-footer">
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center">
                <p class="mb-0">&copy; 2026 Book Hub. All rights reserved.</p>
                <p class="mb-0">Admin Panel v1.0</p>
            </div>
        </div>
    </footer>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="admin-script.js"></script>
<script>
// Sales Chart
const salesCtx = document.getElementById('salesChart').getContext('2d');
const salesChart = new Chart(salesCtx, {
    type: 'line',
    data: {
        labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
        datasets: [{
            label: 'Sales',
            data: [12000, 19000, 15000, 25000, 22000, 30000, 35000],
            borderColor: '#0ea5e9',
            backgroundColor: 'rgba(14, 165, 233, 0.1)',
            tension: 0.4,
            fill: true
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                display: false
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    callback: function(value) {
                        return 'Rs. ' + value.toLocaleString();
                    }
                }
            }
        }
    }
});

// Category Chart
const categoryCtx = document.getElementById('categoryChart').getContext('2d');
const categoryChart = new Chart(categoryCtx, {
    type: 'doughnut',
    data: {
        labels: ['Fiction', 'Technology', 'Science', 'History', 'Other'],
        datasets: [{
            data: [30, 25, 20, 15, 10],
            backgroundColor: [
                '#1e3a8a',
                '#0ea5e9',
                '#10b981',
                '#f59e0b',
                '#64748b'
            ]
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'bottom'
            }
        }
    }
});
</script>

</body>
</html>
