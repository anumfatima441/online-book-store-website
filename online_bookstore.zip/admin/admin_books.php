<?php
include __DIR__ . '/../config.php';
session_start();

if(!isset($_SESSION['admin_id'])){
   header('location:login.php');
   exit();
}

// Fetch all books (handle missing categories table)
$select_books = @mysqli_query($conn, "SELECT b.*, c.name as category_name FROM books b LEFT JOIN categories c ON b.category_id = c.id ORDER BY b.id DESC");
if(!$select_books) {
    $select_books = mysqli_query($conn, "SELECT * FROM books ORDER BY id DESC") or die('query failed');
}

// Handle delete
if(isset($_GET['delete'])){
    $book_id = $_GET['delete'];
    mysqli_query($conn, "DELETE FROM books WHERE id = '$book_id'") or die('query failed');
    header('location:admin_books.php');
    exit();
}

$message = '';
// Handle add/edit book
if(isset($_POST['save_book'])){
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $author = mysqli_real_escape_string($conn, $_POST['author']);
    $price = $_POST['price'];
    $stock = $_POST['stock'];
    $category_id = $_POST['category_id'];
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $rating = $_POST['rating'] ?? 0;
    
    if(isset($_POST['book_id']) && $_POST['book_id'] != ''){
        // Update existing book
        $book_id = $_POST['book_id'];
        mysqli_query($conn, "UPDATE books SET title='$title', author='$author', price='$price', stock='$stock', category_id='$category_id', description='$description', rating='$rating' WHERE id='$book_id'") or die('query failed');
        $message = 'Book updated successfully!';
    } else {
        // Add new book
        mysqli_query($conn, "INSERT INTO books (title, author, price, stock, category_id, description, rating) VALUES ('$title', '$author', '$price', '$stock', '$category_id', '$description', '$rating')") or die('query failed');
        $message = 'Book added successfully!';
    }
}

// Get book for editing
$edit_book = null;
if(isset($_GET['edit'])){
    $edit_id = $_GET['edit'];
    $edit_result = mysqli_query($conn, "SELECT * FROM books WHERE id = '$edit_id'") or die('query failed');
    $edit_book = mysqli_fetch_assoc($edit_result);
}

// Fetch categories for dropdown
$categories = @mysqli_query($conn, "SELECT * FROM categories ORDER BY name");
if(!$categories) {
    // Create dummy result
    $categories = false;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Manage Books - Book Hub Admin</title>
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
   <link rel="stylesheet" href="admin-style.css">
</head>
<body>

<!-- Sidebar -->
<div class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <div class="admin-profile">
            <div class="admin-avatar">
                <i class="fas fa-user-shield"></i>
            </div>
            <div class="admin-info">
                <h6><?php echo $_SESSION['admin_name'] ?? 'Admin'; ?></h6>
                <small>Administrator</small>
            </div>
        </div>
        <button class="sidebar-close d-lg-none" id="sidebarClose">
            <i class="fas fa-times"></i>
        </button>
    </div>
    
    <nav class="sidebar-nav">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="admin.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="admin_profile.php">
                    <i class="fas fa-user-circle"></i>
                    <span>Admin Profile</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="admin_books.php">
                    <i class="fas fa-book"></i>
                    <span>Manage Books</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="admin_categories.php">
                    <i class="fas fa-tags"></i>
                    <span>Categories</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="admin_orders.php">
                    <i class="fas fa-shopping-cart"></i>
                    <span>Orders</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="admin_users.php">
                    <i class="fas fa-users"></i>
                    <span>Users</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="admin_payments.php">
                    <i class="fas fa-credit-card"></i>
                    <span>Payments</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="admin_reviews.php">
                    <i class="fas fa-star"></i>
                    <span>Reviews</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="admin_notifications.php">
                    <i class="fas fa-bell"></i>
                    <span>Notifications</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="admin_reports.php">
                    <i class="fas fa-chart-bar"></i>
                    <span>Reports</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="admin_settings.php">
                    <i class="fas fa-cog"></i>
                    <span>Settings</span>
                </a>
            </li>
            <li class="nav-item mt-3">
                <a class="nav-link text-danger" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul>
    </nav>
</div>

<!-- Main Content -->
<div class="main-content" id="mainContent">
    <!-- Top Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark admin-navbar">
        <div class="container-fluid">
            <button class="sidebar-toggle" id="sidebarToggle">
                <i class="fas fa-bars"></i>
            </button>
            
            <a class="navbar-brand ms-3" href="#">
                <i class="fas fa-book-open"></i>
                <span>Book Hub Admin</span>
            </a>
            
            <div class="d-flex align-items-center ms-auto">
                <div class="dropdown">
                    <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" role="button" data-bs-toggle="dropdown">
                        <div class="admin-mini-avatar">
                            <i class="fas fa-user-shield"></i>
                        </div>
                        <span class="d-none d-md-block ms-2"><?php echo $_SESSION['admin_name'] ?? 'Admin'; ?></span>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="admin_profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                        <li><a class="dropdown-item" href="admin_settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-danger" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>

    <!-- Content Wrapper -->
    <div class="content-wrapper">
        <div class="container-fluid">
            <!-- Page Header -->
            <div class="page-header">
                <div class="row align-items-center">
                    <div class="col">
                        <h2 class="page-title">Manage Books</h2>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="admin.php">Dashboard</a></li>
                                <li class="breadcrumb-item active">Books</li>
                            </ol>
                        </nav>
                    </div>
                    <div class="col-auto">
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#bookModal">
                            <i class="fas fa-plus me-2"></i>Add New Book
                        </button>
                    </div>
                </div>
            </div>

            <?php if($message): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="fas fa-check-circle me-2"></i><?php echo $message; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php endif; ?>

            <!-- Search & Filter -->
            <div class="card mb-4">
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-4">
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-search"></i></span>
                                <input type="text" class="form-control" id="searchBooks" placeholder="Search books...">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <select class="form-select" id="filterCategory">
                                <option value="">All Categories</option>
                                <?php if($categories): mysqli_data_seek($categories, 0); while($cat = mysqli_fetch_assoc($categories)): ?>
                                <option value="<?php echo $cat['id']; ?>"><?php echo $cat['name']; ?></option>
                                <?php endwhile; endif; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <select class="form-select" id="filterStock">
                                <option value="">All Stock</option>
                                <option value="low">Low Stock (&lt;10)</option>
                                <option value="out">Out of Stock</option>
                                <option value="available">In Stock</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <button class="btn btn-outline-secondary w-100" onclick="resetFilters()">
                                <i class="fas fa-undo me-2"></i>Reset
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Books Table -->
            <div class="card table-card">
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0" id="booksTable">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Book</th>
                                    <th>Author</th>
                                    <th>Category</th>
                                    <th>Price</th>
                                    <th>Stock</th>
                                    <th>Rating</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(mysqli_num_rows($select_books) > 0): 
                                    while($book = mysqli_fetch_assoc($select_books)): 
                                        $image = $book['image'] ?: 'https://via.placeholder.com/50x50?text=Book';
                                ?>
                                <tr data-category="<?php echo $book['category_id'] ?? ''; ?>" data-stock="<?php echo $book['stock'] ?? 0; ?>">
                                    <td>#<?php echo $book['id']; ?></td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <img src="<?php echo $image; ?>" alt="" class="me-2" style="width: 40px; height: 50px; object-fit: cover; border-radius: 4px;">
                                            <span><?php echo $book['title']; ?></span>
                                        </div>
                                    </td>
                                    <td><?php echo $book['author']; ?></td>
                                    <td><span class="badge bg-info"><?php echo $book['category_name'] ?? 'Uncategorized'; ?></span></td>
                                    <td><strong>Rs. <?php echo number_format($book['price']); ?></strong></td>
                                    <td>
                                        <?php $stock = $book['stock'] ?? 10; ?>
                                        <span class="badge bg-<?php echo $stock < 5 ? 'danger' : ($stock < 10 ? 'warning' : 'success'); ?>">
                                            <?php echo $stock; ?> in stock
                                        </span>
                                    </td>
                                    <td>
                                        <span class="text-warning">
                                            <?php for($i=1; $i<=5; $i++): ?>
                                                <i class="fas fa-star<?php echo $i <= $book['rating'] ? '' : '-o'; ?>"></i>
                                            <?php endfor; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <a href="admin_books.php?edit=<?php echo $book['id']; ?>" class="btn btn-sm btn-outline-primary me-1" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="book-details.php?id=<?php echo $book['id']; ?>" class="btn btn-sm btn-outline-info me-1" title="View" target="_blank">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="admin_books.php?delete=<?php echo $book['id']; ?>" class="btn btn-sm btn-outline-danger" title="Delete" onclick="return confirm('Are you sure you want to delete this book?')">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endwhile; else: ?>
                                <tr>
                                    <td colspan="8" class="text-center py-4">No books found</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Footer -->
    <footer class="admin-footer">
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center">
                <p class="mb-0">&copy; 2026 Book Hub. All rights reserved.</p>
                <p class="mb-0">Admin Panel v1.0</p>
            </div>
        </div>
    </footer>
</div>

<!-- Book Modal -->
<div class="modal fade" id="bookModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><?php echo $edit_book ? 'Edit Book' : 'Add New Book'; ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="">
                <div class="modal-body">
                    <input type="hidden" name="book_id" value="<?php echo $edit_book['id'] ?? ''; ?>">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Book Title *</label>
                            <input type="text" name="title" class="form-control" value="<?php echo $edit_book['title'] ?? ''; ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Author *</label>
                            <input type="text" name="author" class="form-control" value="<?php echo $edit_book['author'] ?? ''; ?>" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Price (Rs.) *</label>
                            <input type="number" name="price" class="form-control" step="0.01" value="<?php echo $edit_book['price'] ?? ''; ?>" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Stock *</label>
                            <input type="number" name="stock" class="form-control" value="<?php echo $edit_book['stock'] ?? '0'; ?>" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Rating (1-5)</label>
                            <select name="rating" class="form-select">
                                <?php for($i=0; $i<=5; $i++): ?>
                                <option value="<?php echo $i; ?>" <?php echo ($edit_book['rating'] ?? 0) == $i ? 'selected' : ''; ?>><?php echo $i; ?> Star<?php echo $i != 1 ? 's' : ''; ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Category</label>
                            <select name="category_id" class="form-select">
                                <option value="">Select Category</option>
                                <?php if($categories): mysqli_data_seek($categories, 0); while($cat = mysqli_fetch_assoc($categories)): ?>
                                <option value="<?php echo $cat['id']; ?>" <?php echo ($edit_book['category_id'] ?? '') == $cat['id'] ? 'selected' : ''; ?>><?php echo $cat['name']; ?></option>
                                <?php endwhile; endif; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Book Image URL</label>
                            <input type="text" name="image" class="form-control" value="<?php echo $edit_book['image'] ?? ''; ?>">
                        </div>
                        <div class="col-12">
                            <label class="form-label">Description</label>
                            <textarea name="description" class="form-control" rows="4"><?php echo $edit_book['description'] ?? ''; ?></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="save_book" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i>Save Book
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="admin-script.js"></script>
<script>
// Auto-open modal if editing
<?php if($edit_book): ?>
document.addEventListener('DOMContentLoaded', function() {
    var modal = new bootstrap.Modal(document.getElementById('bookModal'));
    modal.show();
});
<?php endif; ?>

// Search and Filter functionality
document.getElementById('searchBooks').addEventListener('input', function() {
    filterTable();
});

document.getElementById('filterCategory').addEventListener('change', function() {
    filterTable();
});

document.getElementById('filterStock').addEventListener('change', function() {
    filterTable();
});

function filterTable() {
    const search = document.getElementById('searchBooks').value.toLowerCase();
    const category = document.getElementById('filterCategory').value;
    const stock = document.getElementById('filterStock').value;
    
    document.querySelectorAll('#booksTable tbody tr').forEach(row => {
        const text = row.textContent.toLowerCase();
        const rowCategory = row.getAttribute('data-category');
        const rowStock = parseInt(row.getAttribute('data-stock'));
        
        let show = text.includes(search);
        
        if(category && rowCategory !== category) show = false;
        
        if(stock) {
            if(stock === 'low' && rowStock >= 10) show = false;
            if(stock === 'out' && rowStock > 0) show = false;
            if(stock === 'available' && rowStock <= 0) show = false;
        }
        
        row.style.display = show ? '' : 'none';
    });
}

function resetFilters() {
    document.getElementById('searchBooks').value = '';
    document.getElementById('filterCategory').value = '';
    document.getElementById('filterStock').value = '';
    filterTable();
}
</script>
</body>
</html>
