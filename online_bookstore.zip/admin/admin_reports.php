<?php
include __DIR__ . '/../config.php';
session_start();
if(!isset($_SESSION['admin_id'])){ header('location:login.php'); exit(); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <title>Reports - Book Hub Admin</title>
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
   <link rel="stylesheet" href="admin-style.css">
</head>
<body>
<div class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <div class="admin-profile">
            <div class="admin-avatar"><i class="fas fa-user-shield"></i></div>
            <div class="admin-info">
                <h6><?php echo $_SESSION['admin_name'] ?? 'Admin'; ?></h6>
                <small>Administrator</small>
            </div>
        </div>
        <button class="sidebar-close d-lg-none" id="sidebarClose"><i class="fas fa-times"></i></button>
    </div>
    <nav class="sidebar-nav">
        <ul class="nav flex-column">
            <li class="nav-item"><a class="nav-link" href="admin.php"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_profile.php"><i class="fas fa-user-circle"></i><span>Admin Profile</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_books.php"><i class="fas fa-book"></i><span>Manage Books</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_categories.php"><i class="fas fa-tags"></i><span>Categories</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_orders.php"><i class="fas fa-shopping-cart"></i><span>Orders</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_users.php"><i class="fas fa-users"></i><span>Users</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_payments.php"><i class="fas fa-credit-card"></i><span>Payments</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_reviews.php"><i class="fas fa-star"></i><span>Reviews</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_notifications.php"><i class="fas fa-bell"></i><span>Notifications</span></a></li>
            <li class="nav-item"><a class="nav-link active" href="admin_reports.php"><i class="fas fa-chart-bar"></i><span>Reports</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_settings.php"><i class="fas fa-cog"></i><span>Settings</span></a></li>
            <li class="nav-item mt-3"><a class="nav-link text-danger" href="logout.php"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a></li>
        </ul>
    </nav>
</div>
<div class="main-content" id="mainContent">
    <nav class="navbar navbar-expand-lg navbar-dark admin-navbar">
        <div class="container-fluid">
            <button class="sidebar-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
            <a class="navbar-brand ms-3" href="#"><i class="fas fa-book-open"></i><span>Book Hub Admin</span></a>
            <div class="d-flex align-items-center ms-auto">
                <div class="dropdown">
                    <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" role="button" data-bs-toggle="dropdown">
                        <div class="admin-mini-avatar"><i class="fas fa-user-shield"></i></div>
                        <span class="d-none d-md-block ms-2"><?php echo $_SESSION['admin_name'] ?? 'Admin'; ?></span>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="admin_profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                        <li><a class="dropdown-item" href="admin_settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-danger" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>
    <div class="content-wrapper">
        <div class="container-fluid">
            <div class="page-header">
                <h2 class="page-title">Reports & Analytics</h2>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="admin.php">Dashboard</a></li>
                        <li class="breadcrumb-item active">Reports</li>
                    </ol>
                </nav>
            </div>
            <div class="row g-4 mb-4">
                <div class="col-xl-3 col-md-6"><div class="stat-card primary"><div class="stat-card-body"><div class="stat-icon"><i class="fas fa-chart-line"></i></div><div class="stat-info"><h3>Rs. 520K</h3><p>Total Sales</p></div></div></div></div>
                <div class="col-xl-3 col-md-6"><div class="stat-card success"><div class="stat-card-body"><div class="stat-icon"><i class="fas fa-shopping-cart"></i></div><div class="stat-info"><h3>1,250</h3><p>Orders</p></div></div></div></div>
                <div class="col-xl-3 col-md-6"><div class="stat-card warning"><div class="stat-card-body"><div class="stat-icon"><i class="fas fa-users"></i></div><div class="stat-info"><h3>850</h3><p>New Users</p></div></div></div></div>
                <div class="col-xl-3 col-md-6"><div class="stat-card info"><div class="stat-card-body"><div class="stat-icon"><i class="fas fa-book"></i></div><div class="stat-info"><h3>150</h3><p>Books Sold</p></div></div></div></div>
            </div>
            <div class="row g-4">
                <div class="col-lg-8">
                    <div class="card chart-card">
                        <div class="card-header d-flex justify-content-between align-items-center"><h5><i class="fas fa-chart-area me-2"></i>Sales Report</h5><div class="btn-group btn-group-sm"><button class="btn btn-outline-primary active">Daily</button><button class="btn btn-outline-primary">Weekly</button><button class="btn btn-outline-primary">Monthly</button></div></div>
                        <div class="card-body"><canvas id="reportChart" height="300"></canvas></div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card"><div class="card-header"><h5><i class="fas fa-file-export me-2"></i>Export Reports</h5></div>
                    <div class="card-body">
                        <div class="d-grid gap-2">
                            <button class="btn btn-outline-primary"><i class="fas fa-file-pdf me-2"></i>Download PDF</button>
                            <button class="btn btn-outline-success"><i class="fas fa-file-excel me-2"></i>Download Excel</button>
                            <button class="btn btn-outline-info"><i class="fas fa-file-csv me-2"></i>Download CSV</button>
                        </div>
                    </div></div>
                    <div class="card mt-4"><div class="card-header"><h5><i class="fas fa-calendar me-2"></i>Date Range</h5></div>
                    <div class="card-body">
                        <div class="mb-3"><label class="form-label">From</label><input type="date" class="form-control"></div>
                        <div class="mb-3"><label class="form-label">To</label><input type="date" class="form-control"></div>
                        <button class="btn btn-primary w-100"><i class="fas fa-filter me-2"></i>Apply Filter</button>
                    </div></div>
                </div>
            </div>
        </div>
    </div>
    <footer class="admin-footer">
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center">
                <p class="mb-0">&copy; 2026 Book Hub. All rights reserved.</p>
                <p class="mb-0">Admin Panel v1.0</p>
            </div>
        </div>
    </footer>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="admin-script.js"></script>
<script>const ctx=document.getElementById('reportChart').getContext('2d');new Chart(ctx,{type:'bar',data:{labels:['Week 1','Week 2','Week 3','Week 4'],datasets:[{label:'Sales',data:[45000,52000,48000,61000],backgroundColor:'#0ea5e9'},{label:'Orders',data:[120,145,132,168],backgroundColor:'#1e3a8a'}]},options:{responsive:true,maintainAspectRatio:false,scales:{y:{beginAtZero:true,ticks:{callback:function(value){return'Rs. '+value;}}}}}});</script>
</body>
</html>
