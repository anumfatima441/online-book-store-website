<?php
include __DIR__ . '/../config.php';
session_start();
if(!isset($_SESSION['admin_id'])){ header('location:login.php'); exit(); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <title>Settings - Book Hub Admin</title>
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
   <link rel="stylesheet" href="admin-style.css">
</head>
<body>
<div class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <div class="admin-profile">
            <div class="admin-avatar"><i class="fas fa-user-shield"></i></div>
            <div class="admin-info">
                <h6><?php echo $_SESSION['admin_name'] ?? 'Admin'; ?></h6>
                <small>Administrator</small>
            </div>
        </div>
        <button class="sidebar-close d-lg-none" id="sidebarClose"><i class="fas fa-times"></i></button>
    </div>
    <nav class="sidebar-nav">
        <ul class="nav flex-column">
            <li class="nav-item"><a class="nav-link" href="admin.php"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_profile.php"><i class="fas fa-user-circle"></i><span>Admin Profile</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_books.php"><i class="fas fa-book"></i><span>Manage Books</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_categories.php"><i class="fas fa-tags"></i><span>Categories</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_orders.php"><i class="fas fa-shopping-cart"></i><span>Orders</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_users.php"><i class="fas fa-users"></i><span>Users</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_payments.php"><i class="fas fa-credit-card"></i><span>Payments</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_reviews.php"><i class="fas fa-star"></i><span>Reviews</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_notifications.php"><i class="fas fa-bell"></i><span>Notifications</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_reports.php"><i class="fas fa-chart-bar"></i><span>Reports</span></a></li>
            <li class="nav-item"><a class="nav-link active" href="admin_settings.php"><i class="fas fa-cog"></i><span>Settings</span></a></li>
            <li class="nav-item mt-3"><a class="nav-link text-danger" href="logout.php"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a></li>
        </ul>
    </nav>
</div>
<div class="main-content" id="mainContent">
    <nav class="navbar navbar-expand-lg navbar-dark admin-navbar">
        <div class="container-fluid">
            <button class="sidebar-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
            <a class="navbar-brand ms-3" href="#"><i class="fas fa-book-open"></i><span>Book Hub Admin</span></a>
            <div class="d-flex align-items-center ms-auto">
                <div class="dropdown">
                    <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" role="button" data-bs-toggle="dropdown">
                        <div class="admin-mini-avatar"><i class="fas fa-user-shield"></i></div>
                        <span class="d-none d-md-block ms-2"><?php echo $_SESSION['admin_name'] ?? 'Admin'; ?></span>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="admin_profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                        <li><a class="dropdown-item" href="admin_settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-danger" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>
    <div class="content-wrapper">
        <div class="container-fluid">
            <div class="page-header">
                <h2 class="page-title">Settings</h2>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="admin.php">Dashboard</a></li>
                        <li class="breadcrumb-item active">Settings</li>
                    </ol>
                </nav>
            </div>
            <div class="row g-4">
                <div class="col-lg-3">
                    <div class="list-group"><a href="#general" class="list-group-item list-group-item-action active" data-bs-toggle="list"><i class="fas fa-cog me-2"></i>General</a><a href="#appearance" class="list-group-item list-group-item-action" data-bs-toggle="list"><i class="fas fa-paint-brush me-2"></i>Appearance</a><a href="#email" class="list-group-item list-group-item-action" data-bs-toggle="list"><i class="fas fa-envelope me-2"></i>Email</a><a href="#security" class="list-group-item list-group-item-action" data-bs-toggle="list"><i class="fas fa-shield-alt me-2"></i>Security</a><a href="#payment" class="list-group-item list-group-item-action" data-bs-toggle="list"><i class="fas fa-credit-card me-2"></i>Payment</a></div>
                </div>
                <div class="col-lg-9">
                    <div class="tab-content">
                        <div class="tab-pane fade show active" id="general">
                            <div class="card"><div class="card-header"><h5><i class="fas fa-cog me-2"></i>General Settings</h5></div>
                            <div class="card-body">
                                <div class="mb-3"><label class="form-label">Store Name</label><input type="text" class="form-control" value="Book Hub"></div>
                                <div class="mb-3"><label class="form-label">Store Email</label><input type="email" class="form-control" value="info@bookhub.com"></div>
                                <div class="mb-3"><label class="form-label">Phone Number</label><input type="tel" class="form-control" value="+92-123-4567890"></div>
                                <div class="mb-3"><label class="form-label">Address</label><textarea class="form-control" rows="3">123 Book Street, Karachi, Pakistan</textarea></div>
                                <div class="mb-3"><label class="form-label">Currency</label><select class="form-select"><option selected>PKR - Pakistani Rupee</option><option>USD - US Dollar</option><option>EUR - Euro</option></select></div>
                                <button class="btn btn-primary"><i class="fas fa-save me-2"></i>Save Changes</button>
                            </div></div>
                        </div>
                        <div class="tab-pane fade" id="appearance">
                            <div class="card"><div class="card-header"><h5><i class="fas fa-paint-brush me-2"></i>Appearance Settings</h5></div>
                            <div class="card-body">
                                <div class="mb-3"><label class="form-label">Logo</label><input type="file" class="form-control"></div>
                                <div class="mb-3"><label class="form-label">Favicon</label><input type="file" class="form-control"></div>
                                <div class="mb-3"><label class="form-label">Primary Color</label><input type="color" class="form-control form-control-color" value="#1e3a8a"></div>
                                <div class="mb-3"><label class="form-label">Accent Color</label><input type="color" class="form-control form-control-color" value="#f59e0b"></div>
                                <button class="btn btn-primary"><i class="fas fa-save me-2"></i>Save Changes</button>
                            </div></div>
                        </div>
                        <div class="tab-pane fade" id="email">
                            <div class="card"><div class="card-header"><h5><i class="fas fa-envelope me-2"></i>Email Settings</h5></div>
                            <div class="card-body">
                                <div class="mb-3"><label class="form-label">SMTP Host</label><input type="text" class="form-control" value="smtp.gmail.com"></div>
                                <div class="mb-3"><label class="form-label">SMTP Port</label><input type="number" class="form-control" value="587"></div>
                                <div class="mb-3"><label class="form-label">SMTP Username</label><input type="text" class="form-control" value="noreply@bookhub.com"></div>
                                <div class="mb-3"><label class="form-label">SMTP Password</label><input type="password" class="form-control" value="********"></div>
                                <div class="form-check mb-3"><input class="form-check-input" type="checkbox" checked><label class="form-check-label">Enable Email Notifications</label></div>
                                <button class="btn btn-primary"><i class="fas fa-save me-2"></i>Save Changes</button>
                            </div></div>
                        </div>
                        <div class="tab-pane fade" id="security">
                            <div class="card"><div class="card-header"><h5><i class="fas fa-shield-alt me-2"></i>Security Settings</h5></div>
                            <div class="card-body">
                                <div class="form-check form-switch mb-3"><input class="form-check-input" type="checkbox" checked><label class="form-check-label">Two-Factor Authentication</label></div>
                                <div class="form-check form-switch mb-3"><input class="form-check-input" type="checkbox" checked><label class="form-check-label">Email Verification for New Users</label></div>
                                <div class="form-check form-switch mb-3"><input class="form-check-input" type="checkbox"><label class="form-check-label">IP Restriction</label></div>
                                <div class="mb-3"><label class="form-label">Session Timeout (minutes)</label><input type="number" class="form-control" value="30"></div>
                                <button class="btn btn-primary"><i class="fas fa-save me-2"></i>Save Changes</button>
                            </div></div>
                        </div>
                        <div class="tab-pane fade" id="payment">
                            <div class="card"><div class="card-header"><h5><i class="fas fa-credit-card me-2"></i>Payment Settings</h5></div>
                            <div class="card-body">
                                <div class="form-check form-switch mb-3"><input class="form-check-input" type="checkbox" checked><label class="form-check-label">Cash on Delivery</label></div>
                                <div class="form-check form-switch mb-3"><input class="form-check-input" type="checkbox" checked><label class="form-check-label">Credit/Debit Cards</label></div>
                                <div class="form-check form-switch mb-3"><input class="form-check-input" type="checkbox"><label class="form-check-label">Bank Transfer</label></div>
                                <div class="form-check form-switch mb-3"><input class="form-check-input" type="checkbox"><label class="form-check-label">Mobile Wallet</label></div>
                                <div class="mb-3"><label class="form-label">Tax Rate (%)</label><input type="number" class="form-control" value="16" step="0.01"></div>
                                <div class="mb-3"><label class="form-label">Shipping Fee (Rs.)</label><input type="number" class="form-control" value="150"></div>
                                <button class="btn btn-primary"><i class="fas fa-save me-2"></i>Save Changes</button>
                            </div></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <footer class="admin-footer">
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center">
                <p class="mb-0">&copy; 2026 Book Hub. All rights reserved.</p>
                <p class="mb-0">Admin Panel v1.0</p>
            </div>
        </div>
    </footer>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="admin-script.js"></script>
</body>
</html>
