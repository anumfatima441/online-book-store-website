<?php
include __DIR__ . '/../config.php';
session_start();
if(!isset($_SESSION['admin_id'])){ header('location:login.php'); exit(); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <title>Payments - Book Hub Admin</title>
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
   <link rel="stylesheet" href="admin-style.css">
</head>
<body>
<div class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <div class="admin-profile">
            <div class="admin-avatar"><i class="fas fa-user-shield"></i></div>
            <div class="admin-info">
                <h6><?php echo $_SESSION['admin_name'] ?? 'Admin'; ?></h6>
                <small>Administrator</small>
            </div>
        </div>
        <button class="sidebar-close d-lg-none" id="sidebarClose"><i class="fas fa-times"></i></button>
    </div>
    <nav class="sidebar-nav">
        <ul class="nav flex-column">
            <li class="nav-item"><a class="nav-link" href="admin.php"><i class="fas fa-tachometer-alt"></i><span>Dashboard</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_profile.php"><i class="fas fa-user-circle"></i><span>Admin Profile</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_books.php"><i class="fas fa-book"></i><span>Manage Books</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_categories.php"><i class="fas fa-tags"></i><span>Categories</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_orders.php"><i class="fas fa-shopping-cart"></i><span>Orders</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_users.php"><i class="fas fa-users"></i><span>Users</span></a></li>
            <li class="nav-item"><a class="nav-link active" href="admin_payments.php"><i class="fas fa-credit-card"></i><span>Payments</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_reviews.php"><i class="fas fa-star"></i><span>Reviews</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_notifications.php"><i class="fas fa-bell"></i><span>Notifications</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_reports.php"><i class="fas fa-chart-bar"></i><span>Reports</span></a></li>
            <li class="nav-item"><a class="nav-link" href="admin_settings.php"><i class="fas fa-cog"></i><span>Settings</span></a></li>
            <li class="nav-item mt-3"><a class="nav-link text-danger" href="logout.php"><i class="fas fa-sign-out-alt"></i><span>Logout</span></a></li>
        </ul>
    </nav>
</div>
<div class="main-content" id="mainContent">
    <nav class="navbar navbar-expand-lg navbar-dark admin-navbar">
        <div class="container-fluid">
            <button class="sidebar-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
            <a class="navbar-brand ms-3" href="#"><i class="fas fa-book-open"></i><span>Book Hub Admin</span></a>
            <div class="d-flex align-items-center ms-auto">
                <div class="dropdown">
                    <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" role="button" data-bs-toggle="dropdown">
                        <div class="admin-mini-avatar"><i class="fas fa-user-shield"></i></div>
                        <span class="d-none d-md-block ms-2"><?php echo $_SESSION['admin_name'] ?? 'Admin'; ?></span>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="admin_profile.php"><i class="fas fa-user me-2"></i>Profile</a></li>
                        <li><a class="dropdown-item" href="admin_settings.php"><i class="fas fa-cog me-2"></i>Settings</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-danger" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>
    <div class="content-wrapper">
        <div class="container-fluid">
            <div class="page-header">
                <h2 class="page-title">Payments</h2>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="admin.php">Dashboard</a></li>
                        <li class="breadcrumb-item active">Payments</li>
                    </ol>
                </nav>
            </div>
            <div class="row g-4 mb-4">
                <div class="col-xl-3 col-md-6"><div class="stat-card primary"><div class="stat-card-body"><div class="stat-icon"><i class="fas fa-wallet"></i></div><div class="stat-info"><h3>Rs. 520K</h3><p>Total Revenue</p></div></div></div></div>
                <div class="col-xl-3 col-md-6"><div class="stat-card success"><div class="stat-card-body"><div class="stat-icon"><i class="fas fa-check-circle"></i></div><div class="stat-info"><h3>850</h3><p>Successful</p></div></div></div></div>
                <div class="col-xl-3 col-md-6"><div class="stat-card warning"><div class="stat-card-body"><div class="stat-icon"><i class="fas fa-clock"></i></div><div class="stat-info"><h3>12</h3><p>Pending</p></div></div></div></div>
                <div class="col-xl-3 col-md-6"><div class="stat-card danger"><div class="stat-card-body"><div class="stat-icon"><i class="fas fa-times-circle"></i></div><div class="stat-info"><h3>3</h3><p>Failed</p></div></div></div></div>
            </div>
            <div class="card table-card">
                <div class="card-header"><h5><i class="fas fa-credit-card me-2"></i>Recent Transactions</h5></div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead><tr><th>Transaction ID</th><th>Customer</th><th>Amount</th><th>Method</th><th>Status</th><th>Date</th></tr></thead>
                            <tbody>
                                <tr><td>#TXN-001</td><td>John Doe</td><td><strong>Rs. 2,500</strong></td><td><i class="fab fa-cc-visa me-2"></i>Visa</td><td><span class="badge bg-success">Completed</span></td><td>Jan 30, 2026</td></tr>
                                <tr><td>#TXN-002</td><td>Jane Smith</td><td><strong>Rs. 4,200</strong></td><td><i class="fas fa-money-bill me-2"></i>Cash</td><td><span class="badge bg-success">Completed</span></td><td>Jan 29, 2026</td></tr>
                                <tr><td>#TXN-003</td><td>Ali Khan</td><td><strong>Rs. 1,800</strong></td><td><i class="fas fa-university me-2"></i>Bank</td><td><span class="badge bg-warning">Pending</span></td><td>Jan 29, 2026</td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <footer class="admin-footer">
        <div class="container-fluid">
            <div class="d-flex justify-content-between align-items-center">
                <p class="mb-0">&copy; 2026 Book Hub. All rights reserved.</p>
                <p class="mb-0">Admin Panel v1.0</p>
            </div>
        </div>
    </footer>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="admin-script.js"></script>
</body>
</html>
